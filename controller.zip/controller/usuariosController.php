<?php
require_once($_SERVER['DOCUMENT_ROOT']."/segcontrol/persistencia/usuariosDao.php");

class usuariosController{

  public function PerfilEmpleado($id){
        $ud=new usuariosDao();
        $obj = $ud->CargarPerfilEmpleado($id);
        $cookie = array(
            "id_empleado" => $obj[0]->getId_usuario(),
            "id_usuario" => $obj[0]->getId_usuario(),
            "nombre" => $obj[0]->getNombre(),
            "tipo_documento" => $obj[0]->getTipo_documento(),
            "numero_documento" => $obj[0]->getNumero_documento(),
            "direccion" => $obj[0]->getDireccion(),
            "ciudad" => $obj[0]->getCiudad(),
            "fijo" => $obj[0]->getFijo(),
            "celular1" => $obj[0]->getCelular1(),
            "celular2" => $obj[0]->getCelular2(),
            "celular3" => $obj[0]->getCelular3(),
            "email" => $obj[0]->getEmail(),
            "foto" => $obj[0]->getFoto()
          );
        return $cookie;
}

public function actualizarPerfil($usuario,$rol,$estado,$id){

      $ud=new usuariosDao();
      return  $ud->actualizarPerfil($usuario,$rol,$estado,$id);
}

}


?>
