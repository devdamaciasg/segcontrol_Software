<?php
 echo "<br> ".dirname(dirname(__FILE__));
  echo "<br> ".$_SERVER['DOCUMENT_ROOT'];

 




?>