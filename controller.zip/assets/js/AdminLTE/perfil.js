$(document).on('click','#datos_usuario',function(e){
e.stopPropagation();
e.preventDefault();

  if(datos_usuario.value == "Editar"){
    document.getElementById("selectRol").disabled=false;
    document.getElementById("usuario").disabled=false;
    document.getElementById("selectEstado").disabled=false;
    datos_usuario.value="Actualizar";
  }else{


    var rol =document.getElementById("selectRol").value;
    var usuario =document.getElementById("usuario").value;
    var estado =document.getElementById("selectEstado").value;
    var id=document.getElementById("idHidden").value;
    var params = { "usuario" : usuario, "rol" : rol , "estado" : estado,"id" : id};
    $.ajax({
      data:   params,
      url:   '../controller/route/perfil.php',
      type:  'post',
      beforeSend: function () {
        //mostramos gif "cargando"
        //jQuery('#loading_spinner').show();
        //antes de enviar la petición al fichero PHP, mostramos mensaje
        $("#smg").html("Validando...");
      },
      success:  function (response) {

        $("#smg").html(response);
        $('#modal1').modal('show');
      }});
      document.getElementById("selectRol").disabled=true;
      document.getElementById("usuario").disabled=true;
      document.getElementById("selectEstado").disabled=true;
    datos_usuario.value="Editar";
  }
});
/****************************************************************************/
$(document).on('click','#datos_clave',function(e){
e.stopPropagation();
e.preventDefault();

  if(datos_clave.value == "Editar"){
    document.getElementById("selectRol").disabled=false;
    document.getElementById("usuario").disabled=false;
    document.getElementById("selectEstado").disabled=false;
    datos_clave.value="Cambiar";
  }else{


    var rol =document.getElementById("selectRol").value;
    var usuario =document.getElementById("usuario").value;
    var estado =document.getElementById("selectEstado").value;
    var id=document.getElementById("idHidden").value;
    var params = { "usuario" : usuario, "rol" : rol , "estado" : estado,"id" : id};
    $.ajax({
      data:   params,
      url:   '../controller/route/perfil.php',
      type:  'post',
      beforeSend: function () {
        //mostramos gif "cargando"
        //jQuery('#loading_spinner').show();
        //antes de enviar la petición al fichero PHP, mostramos mensaje
        $("#smg").html("Validando...");
      },
      success:  function (response) {

        $("#smg").html(response);
        $('#modal1').modal('show');
      }});
      document.getElementById("selectRol").disabled=true;
      document.getElementById("usuario").disabled=true;
      document.getElementById("selectEstado").disabled=true;
    datos_clave.value="Editar";
  }
});
