<?php
require_once ($_SERVER['DOCUMENT_ROOT']."/segcontrol/persistencia/DataSource.php");
require_once ($_SERVER['DOCUMENT_ROOT']."/segcontrol/model/empleado.php");
class usuariosDao
{
	public function CargarPerfilEmpleado($id){

		$data_source = new DataSource();
		$data_empleado = $data_source->ejecutarConsulta(" SELECT *
		FROM empleado JOIN usuario  on (empleado.id_usuario=usuario.id_usuario)
                  JOIN rol ON(usuario.id_rol=rol.id_rol)
		where empleado.id_usuario = :id ",array(':id'=>$id));
		$sesion = array();
		if(count($data_empleado) >= 1){
			foreach ($data_empleado as $clave => $valor) {
				  $empleadoObj  = new empleado(
					$data_empleado[$clave]["id_empleado"],
					$data_empleado[$clave]["id_usuario"],
					$data_empleado[$clave]["nombre"],
					$data_empleado[$clave]["tipo_documento"],
					$data_empleado[$clave]["numero_documento"],
					$data_empleado[$clave]["direccion"],
          $data_empleado[$clave]["ciudad"],
          $data_empleado[$clave]["fijo"],
          $data_empleado[$clave]["celular1"],
          $data_empleado[$clave]["celular2"],
          $data_empleado[$clave]["celular3"],
          $data_empleado[$clave]["email"],
          $data_empleado[$clave]["foto"] );
					array_push($sesion, $empleadoObj);
			}
			return $sesion;
		}else{	return null;}
	}//end method
  public function actualizarPerfil($usuario,$rol,$estado,$id){

		$data_source = new DataSource();
		if($rol == "administrador"){
			 $rol=1;
		}else{
			if($rol == "cliente"){
				 $rol=3;
			}else{
				 $rol=2;
			}
		}
		$sql = "UPDATE usuario SET 'usuario' = :usuario,
				'estado' = :estado,
				'id_rol' = :rol
				WHERE 'usuario.id_usuario' = :id
				";
		$resultado = $data_source->ejecutarActualizacion($sql,array(
			':usuario'=> $usuario,
			':estado' => $estado,
			':id' => $id,
			':id_rol' =>  $rol)
		);
		return $resultado;
	}
}
?>
